<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to add favorites']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$propertyId = intval($data['property_id'] ?? 0);
$userId = getCurrentUserId();

if ($propertyId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid property ID']);
    exit;
}

$conn = getDBConnection();

// Check if already favorited
$checkStmt = $conn->prepare("SELECT id FROM favorites WHERE user_id = ? AND property_id = ?");
$checkStmt->bind_param("ii", $userId, $propertyId);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows > 0) {
    // Remove from favorites
    $checkStmt->close();
    $deleteStmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND property_id = ?");
    $deleteStmt->bind_param("ii", $userId, $propertyId);
    $deleteStmt->execute();
    $deleteStmt->close();
    
    echo json_encode([
        'success' => true,
        'message' => 'Removed from favorites',
        'is_favorite' => false
    ]);
} else {
    // Add to favorites
    $checkStmt->close();
    $insertStmt = $conn->prepare("INSERT INTO favorites (user_id, property_id) VALUES (?, ?)");
    $insertStmt->bind_param("ii", $userId, $propertyId);
    $insertStmt->execute();
    $insertStmt->close();
    
    echo json_encode([
        'success' => true,
        'message' => 'Added to favorites',
        'is_favorite' => true
    ]);
}

closeDBConnection($conn);
?>
