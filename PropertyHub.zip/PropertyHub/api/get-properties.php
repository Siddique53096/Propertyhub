<?php
require_once '../config/database.php';
setJSONHeader();

$conn = getDBConnection();

// Get filter parameters
$propertyType = sanitizeInput($_GET['type'] ?? 'all');
$city = sanitizeInput($_GET['city'] ?? '');
$location = sanitizeInput($_GET['location'] ?? '');
$priceRange = sanitizeInput($_GET['price_range'] ?? 'any');
$limit = intval($_GET['limit'] ?? 20);
$offset = intval($_GET['offset'] ?? 0);

// Build query
$query = "SELECT p.*, u.full_name as owner_name, u.phone as owner_phone, u.email as owner_email,
          (SELECT image_path FROM property_images WHERE property_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
          (SELECT COUNT(*) FROM favorites WHERE property_id = p.id) as favorite_count
          FROM properties p
          JOIN users u ON p.user_id = u.id
          WHERE p.status = 'available'";

$params = [];
$types = "";

if ($propertyType !== 'all') {
    $query .= " AND p.property_type = ?";
    $params[] = $propertyType;
    $types .= "s";
}

if (!empty($city)) {
    $query .= " AND p.city LIKE ?";
    $params[] = "%$city%";
    $types .= "s";
}

if (!empty($location)) {
    $query .= " AND (p.location LIKE ? OR p.address LIKE ?)";
    $params[] = "%$location%";
    $params[] = "%$location%";
    $types .= "ss";
}

if ($priceRange !== 'any') {
    switch ($priceRange) {
        case 'under-50':
            $query .= " AND p.price < 5000000";
            break;
        case '50-100':
            $query .= " AND p.price BETWEEN 5000000 AND 10000000";
            break;
        case '100-200':
            $query .= " AND p.price BETWEEN 10000000 AND 20000000";
            break;
        case 'above-200':
            $query .= " AND p.price > 20000000";
            break;
    }
}

$query .= " ORDER BY p.featured DESC, p.created_at DESC LIMIT ? OFFSET ?";
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$properties = [];
while ($row = $result->fetch_assoc()) {
    $properties[] = $row;
}

echo json_encode([
    'success' => true,
    'properties' => $properties,
    'count' => count($properties)
]);

$stmt->close();
closeDBConnection($conn);
?>
