<?php
require_once '../config/database.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$fullName = sanitizeInput($data['full_name'] ?? '');
$email = sanitizeInput($data['email'] ?? '');
$phone = sanitizeInput($data['phone'] ?? '');
$password = $data['password'] ?? '';
$userType = sanitizeInput($data['user_type'] ?? 'buyer');

// Validation
if (empty($fullName) || empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
    exit;
}

$conn = getDBConnection();

// Check if email already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Email already registered']);
    $stmt->close();
    closeDBConnection($conn);
    exit;
}
$stmt->close();

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert user
$stmt = $conn->prepare("INSERT INTO users (full_name, email, phone, password, user_type) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $fullName, $email, $phone, $hashedPassword, $userType);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'user_id' => $conn->insert_id
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Registration failed']);
}

$stmt->close();
closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PropertyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
        <nav class="nav">
            <a href="index.html" class="logo">PropertyHub</a>
            <div class="nav-right">
                <a href="index.html" class="nav-link">Home</a>
                <a href="login.html" class="signin-btn">Sign in</a>
            </div>
        </nav>
    </header>

    <div class="auth-container">
        <div class="auth-card">
            <h2>Create Account</h2>
            <p class="auth-subtitle">Join PropertyHub to buy and sell properties</p>
            
            <form id="registerForm" onsubmit="handleRegister(event)">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" id="fullName" required>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" id="phone" placeholder="03001234567">
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" required minlength="6">
                </div>
                
                <div class="form-group">
                    <label>I want to</label>
                    <select id="userType" required>
                        <option value="buyer">Buy Property</option>
                        <option value="seller">Sell Property</option>
                        <option value="both">Both</option>
                    </select>
                </div>
                
                <div id="errorMessage" class="error-message" style="display: none;"></div>
                
                <button type="submit" class="submit-btn" id="submitBtn">
                    Create Account
                </button>
            </form>
            
            <p class="auth-footer">
                Already have an account? <a href="login.html">Sign in</a>
            </p>
        </div>
    </div>

    <script src="js/main.js"></script>
    <script src="js/register.js"></script>
</body>
</html>
