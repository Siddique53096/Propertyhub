<?php
require_once '../config/database.php';
setJSONHeader();

$propertyId = intval($_GET['id'] ?? 0);

if ($propertyId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid property ID']);
    exit;
}

$conn = getDBConnection();

// Update view count
$updateStmt = $conn->prepare("UPDATE properties SET views = views + 1 WHERE id = ?");
$updateStmt->bind_param("i", $propertyId);
$updateStmt->execute();
$updateStmt->close();

// Get property details
$stmt = $conn->prepare("SELECT p.*, u.full_name as owner_name, u.phone as owner_phone, u.email as owner_email
                        FROM properties p
                        JOIN users u ON p.user_id = u.id
                        WHERE p.id = ?");
$stmt->bind_param("i", $propertyId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Property not found']);
    $stmt->close();
    closeDBConnection($conn);
    exit;
}

$property = $result->fetch_assoc();
$stmt->close();

// Get property images
$imgStmt = $conn->prepare("SELECT image_path, is_primary FROM property_images WHERE property_id = ? ORDER BY is_primary DESC, id ASC");
$imgStmt->bind_param("i", $propertyId);
$imgStmt->execute();
$imgResult = $imgStmt->get_result();

$images = [];
while ($img = $imgResult->fetch_assoc()) {
    $images[] = $img;
}
$imgStmt->close();

$property['images'] = $images;

echo json_encode([
    'success' => true,
    'property' => $property
]);

closeDBConnection($conn);
?>
