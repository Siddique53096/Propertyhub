<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$email = sanitizeInput($data['email'] ?? '');
$password = $data['password'] ?? '';

if (empty($email) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required']);
    exit;
}

$conn = getDBConnection();

$stmt = $conn->prepare("SELECT id, full_name, email, phone, password, user_type FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
    $stmt->close();
    closeDBConnection($conn);
    exit;
}

$user = $result->fetch_assoc();

if (password_verify($password, $user['password'])) {
    loginUser($user['id'], $user);
    
    echo json_encode([
        'success' => true,
        'message' => 'Login successful',
        'user' => [
            'id' => $user['id'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'user_type' => $user['user_type']
        ]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
}

$stmt->close();
closeDBConnection($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PropertyHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="header">
        <nav class="nav">
            <a href="index.html" class="logo">PropertyHub</a>
            <div class="nav-right">
                <a href="index.html" class="nav-link">Home</a>
                <a href="register.html" class="register-btn">Register</a>
            </div>
        </nav>
    </header>

    <div class="auth-container">
        <div class="auth-card">
            <h2>Welcome Back</h2>
            <p class="auth-subtitle">Sign in to your PropertyHub account</p>
            
            <form id="loginForm" onsubmit="handleLogin(event)">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" id="email" required>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="password" required>
                </div>
                
                <div id="errorMessage" class="error-message" style="display: none;"></div>
                
                <button type="submit" class="submit-btn" id="submitBtn">
                    Sign In
                </button>
            </form>
            
            <p class="auth-footer">
                Don't have an account? <a href="register.html">Register</a>
            </p>
        </div>
    </div>

    <script src="js/main.js"></script>
    <script src="js/login.js"></script>
</body>
</html>
