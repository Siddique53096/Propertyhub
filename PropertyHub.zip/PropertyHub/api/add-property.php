<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to add property']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$userId = getCurrentUserId();
$title = sanitizeInput($data['title'] ?? '');
$description = sanitizeInput($data['description'] ?? '');
$propertyType = sanitizeInput($data['property_type'] ?? '');
$listingType = sanitizeInput($data['listing_type'] ?? 'sale');
$price = floatval($data['price'] ?? 0);
$city = sanitizeInput($data['city'] ?? '');
$location = sanitizeInput($data['location'] ?? '');
$address = sanitizeInput($data['address'] ?? '');
$area = sanitizeInput($data['area'] ?? '');
$bedrooms = intval($data['bedrooms'] ?? 0);
$bathrooms = intval($data['bathrooms'] ?? 0);
$parking = intval($data['parking'] ?? 0);
$floors = intval($data['floors'] ?? 0);

// Validation
if (empty($title) || empty($propertyType) || $price <= 0 || empty($city) || empty($location)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit;
}

$conn = getDBConnection();

$stmt = $conn->prepare("INSERT INTO properties (user_id, title, description, property_type, listing_type, price, city, location, address, area, bedrooms, bathrooms, parking, floors) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issssdssssiiis", $userId, $title, $description, $propertyType, $listingType, $price, $city, $location, $address, $area, $bedrooms, $bathrooms, $parking, $floors);

if ($stmt->execute()) {
    $propertyId = $conn->insert_id;
    echo json_encode([
        'success' => true,
        'message' => 'Property added successfully',
        'property_id' => $propertyId
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add property']);
}

$stmt->close();
closeDBConnection($conn);
?>
