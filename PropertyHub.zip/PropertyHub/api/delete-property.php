<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login']);
    exit;
}

$propertyId = intval($_GET['id'] ?? 0);
$userId = getCurrentUserId();

if ($propertyId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid property ID']);
    exit;
}

$conn = getDBConnection();

// Verify ownership
$checkStmt = $conn->prepare("SELECT id FROM properties WHERE id = ? AND user_id = ?");
$checkStmt->bind_param("ii", $propertyId, $userId);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Property not found or unauthorized']);
    $checkStmt->close();
    closeDBConnection($conn);
    exit;
}
$checkStmt->close();

// Delete property (cascade will delete images and favorites)
$deleteStmt = $conn->prepare("DELETE FROM properties WHERE id = ? AND user_id = ?");
$deleteStmt->bind_param("ii", $propertyId, $userId);

if ($deleteStmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Property deleted successfully'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to delete property']);
}

$deleteStmt->close();
closeDBConnection($conn);
?>
