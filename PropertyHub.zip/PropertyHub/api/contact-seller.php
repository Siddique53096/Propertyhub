<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$propertyId = intval($data['property_id'] ?? 0);
$senderName = sanitizeInput($data['sender_name'] ?? '');
$senderEmail = sanitizeInput($data['sender_email'] ?? '');
$senderPhone = sanitizeInput($data['sender_phone'] ?? '');
$message = sanitizeInput($data['message'] ?? '');
$senderId = isLoggedIn() ? getCurrentUserId() : null;

// Validation
if ($propertyId <= 0 || empty($senderName) || empty($senderEmail) || empty($message)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit;
}

if (!filter_var($senderEmail, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit;
}

$conn = getDBConnection();

$stmt = $conn->prepare("INSERT INTO contact_messages (property_id, sender_id, sender_name, sender_email, sender_phone, message) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("iissss", $propertyId, $senderId, $senderName, $senderEmail, $senderPhone, $message);

if ($stmt->execute()) {
    echo json_encode([
        'success' => true,
        'message' => 'Message sent successfully'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send message']);
}

$stmt->close();
closeDBConnection($conn);
?>
