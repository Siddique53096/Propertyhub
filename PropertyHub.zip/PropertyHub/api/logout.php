<?php
require_once '../includes/auth.php';
require_once '../config/database.php';
setJSONHeader();

logoutUser();

echo json_encode([
    'success' => true,
    'message' => 'Logout successful'
]);
?>
