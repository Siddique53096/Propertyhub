<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to view your properties']);
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();

$stmt = $conn->prepare("SELECT p.*,
                        (SELECT image_path FROM property_images WHERE property_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
                        (SELECT COUNT(*) FROM favorites WHERE property_id = p.id) as favorite_count,
                        (SELECT COUNT(*) FROM contact_messages WHERE property_id = p.id) as message_count
                        FROM properties p
                        WHERE p.user_id = ?
                        ORDER BY p.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$properties = [];
while ($row = $result->fetch_assoc()) {
    $properties[] = $row;
}

echo json_encode([
    'success' => true,
    'properties' => $properties,
    'count' => count($properties)
]);

$stmt->close();
closeDBConnection($conn);
?>
