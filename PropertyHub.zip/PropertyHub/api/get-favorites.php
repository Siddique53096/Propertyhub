<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
setJSONHeader();

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Please login to view favorites']);
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();

$stmt = $conn->prepare("SELECT p.*, u.full_name as owner_name,
                        (SELECT image_path FROM property_images WHERE property_id = p.id AND is_primary = 1 LIMIT 1) as primary_image,
                        f.created_at as favorited_at
                        FROM favorites f
                        JOIN properties p ON f.property_id = p.id
                        JOIN users u ON p.user_id = u.id
                        WHERE f.user_id = ?
                        ORDER BY f.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$favorites = [];
while ($row = $result->fetch_assoc()) {
    $favorites[] = $row;
}

echo json_encode([
    'success' => true,
    'favorites' => $favorites,
    'count' => count($favorites)
]);

$stmt->close();
closeDBConnection($conn);
?>
